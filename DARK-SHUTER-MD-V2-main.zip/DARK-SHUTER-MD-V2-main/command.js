/**

██████╗░░█████╗░██████╗░██╗░░██╗  ░██████╗██╗░░██╗██╗░░░██╗████████╗███████╗██████╗░  ███╗░░░███╗██████╗░
██╔══██╗██╔══██╗██╔══██╗██║░██╔╝  ██╔════╝██║░░██║██║░░░██║╚══██╔══╝██╔════╝██╔══██╗  ████╗░████║██╔══██╗
██║░░██║███████║██████╔╝█████═╝░  ╚█████╗░███████║██║░░░██║░░░██║░░░█████╗░░██████╔╝  ██╔████╔██║██║░░██║
██║░░██║██╔══██║██╔══██╗██╔═██╗░  ░╚═══██╗██╔══██║██║░░░██║░░░██║░░░██╔══╝░░██╔══██╗  ██║╚██╔╝██║██║░░██║
██████╔╝██║░░██║██║░░██║██║░╚██╗  ██████╔╝██║░░██║╚██████╔╝░░░██║░░░███████╗██║░░██║  ██║░╚═╝░██║██████╔╝
╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝  ╚═════╝░╚═╝░░╚═╝░╚═════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝  ╚═╝░░░░░╚═╝╚═════╝░

© Project name - DARK SHUTER MD V2
© Author - Darksadas YT
© Date - 2024/11/28*/



var _0x257644=_0x4219;(function(_0x1eb9c8,_0x5dc201){var _0x16e30b=_0x4219,_0x2000eb=_0x1eb9c8();while(!![]){try{var _0x5115b7=parseInt(_0x16e30b(0x9e))/0x1*(parseInt(_0x16e30b(0xa0))/0x2)+parseInt(_0x16e30b(0xa7))/0x3+parseInt(_0x16e30b(0xa5))/0x4+-parseInt(_0x16e30b(0xa6))/0x5+parseInt(_0x16e30b(0xaa))/0x6*(parseInt(_0x16e30b(0xab))/0x7)+-parseInt(_0x16e30b(0x9a))/0x8+-parseInt(_0x16e30b(0xa2))/0x9;if(_0x5115b7===_0x5dc201)break;else _0x2000eb['push'](_0x2000eb['shift']());}catch(_0x30aa23){_0x2000eb['push'](_0x2000eb['shift']());}}}(_0x3ca7,0x52a4e));function _0x4219(_0x26a183,_0x39b4e7){var _0x3ca7c2=_0x3ca7();return _0x4219=function(_0x421990,_0x57fd13){_0x421990=_0x421990-0x9a;var _0x27b36d=_0x3ca7c2[_0x421990];return _0x27b36d;},_0x4219(_0x26a183,_0x39b4e7);}var commands=[];function cmd(_0x2cc57f,_0x4991a6){var _0x761ab3=_0x4219,_0x4019d2=_0x2cc57f;_0x4019d2['function']=_0x4991a6;if(!_0x4019d2[_0x761ab3(0xa8)])_0x4019d2[_0x761ab3(0xa8)]=![];if(!_0x2cc57f[_0x761ab3(0x9c)])_0x2cc57f[_0x761ab3(0x9c)]='';if(!_0x4019d2[_0x761ab3(0xa3)])_0x4019d2[_0x761ab3(0xa3)]=![];if(!_0x2cc57f[_0x761ab3(0x9d)])_0x4019d2[_0x761ab3(0x9d)]=_0x761ab3(0x9f);if(!_0x2cc57f[_0x761ab3(0xa4)])_0x4019d2[_0x761ab3(0xa4)]=_0x761ab3(0xa9);return commands[_0x761ab3(0xa1)](_0x4019d2),_0x4019d2;}function _0x3ca7(){var _0x2054fe=['category','307NDbIsD','misc','3972inxClS','push','8020557NFfhnJ','fromMe','filename','1227532AyKdvF','497955JhhaAO','1306863ugLAWw','dontAddCommandList','Not\x20Provided','6GkIJoW','1369312FGYvqi','1748384GiqvvJ','exports','desc'];_0x3ca7=function(){return _0x2054fe;};return _0x3ca7();}module[_0x257644(0x9b)]={'cmd':cmd,'AddCommand':cmd,'Function':cmd,'Module':cmd,'commands':commands};
