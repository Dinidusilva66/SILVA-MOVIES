/**

██████╗░░█████╗░██████╗░██╗░░██╗  ░██████╗██╗░░██╗██╗░░░██╗████████╗███████╗██████╗░  ███╗░░░███╗██████╗░
██╔══██╗██╔══██╗██╔══██╗██║░██╔╝  ██╔════╝██║░░██║██║░░░██║╚══██╔══╝██╔════╝██╔══██╗  ████╗░████║██╔══██╗
██║░░██║███████║██████╔╝█████═╝░  ╚█████╗░███████║██║░░░██║░░░██║░░░█████╗░░██████╔╝  ██╔████╔██║██║░░██║
██║░░██║██╔══██║██╔══██╗██╔═██╗░  ░╚═══██╗██╔══██║██║░░░██║░░░██║░░░██╔══╝░░██╔══██╗  ██║╚██╔╝██║██║░░██║
██████╔╝██║░░██║██║░░██║██║░╚██╗  ██████╔╝██║░░██║╚██████╔╝░░░██║░░░███████╗██║░░██║  ██║░╚═╝░██║██████╔╝
╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝  ╚═════╝░╚═╝░░╚═╝░╚═════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝  ╚═╝░░░░░╚═╝╚═════╝░

© Project name - DARK SHUTER MD V2
© Author - Darksadas YT
© Date - 2024/11/28*/



const _0x2521fb=_0x43b1;function _0x43b1(_0x144668,_0x117a47){const _0x59508f=_0x5950();return _0x43b1=function(_0x43b168,_0x306b43){_0x43b168=_0x43b168-0x11a;let _0x200b1e=_0x59508f[_0x43b168];return _0x200b1e;},_0x43b1(_0x144668,_0x117a47);}(function(_0x1f4d9c,_0x1c46b8){const _0x1a12ea=_0x43b1,_0x4f6a41=_0x1f4d9c();while(!![]){try{const _0x2b9769=-parseInt(_0x1a12ea(0x124))/0x1+-parseInt(_0x1a12ea(0x11a))/0x2+parseInt(_0x1a12ea(0x122))/0x3+-parseInt(_0x1a12ea(0x120))/0x4*(parseInt(_0x1a12ea(0x123))/0x5)+-parseInt(_0x1a12ea(0x11c))/0x6*(-parseInt(_0x1a12ea(0x11b))/0x7)+parseInt(_0x1a12ea(0x11e))/0x8+parseInt(_0x1a12ea(0x12a))/0x9*(parseInt(_0x1a12ea(0x121))/0xa);if(_0x2b9769===_0x1c46b8)break;else _0x4f6a41['push'](_0x4f6a41['shift']());}catch(_0x5710a0){_0x4f6a41['push'](_0x4f6a41['shift']());}}}(_0x5950,0xda3d1));const {getBuffer,getGroupAdmins,getRandom,h2k,isUrl,Json,runtime,sleep,fetchJson,getsize}=require(_0x2521fb(0x11d));function btregex(_0x508195){const _0x4922e0=_0x2521fb,_0x1faaf6=_0x4922e0(0x125);return h2k(_0x1faaf6[_0x4922e0(0x12b)](_0x508195));}function _0x5950(){const _0x2f2bf1=['7855msxOor','1048754YtvJKu','/({11})/','push','*Select\x20number','export','\x0a*[','81jJfFGR','test','2002268wAXGef','2358797mYrPzI','6OXsntW','./lib/functions','4682600fIWKXA','forEach','84hdcDDm','1460770UuBewR','2219385PsSdZO'];_0x5950=function(){return _0x2f2bf1;};return _0x5950();}buttonMessage=async(_0x1305d0,_0x51c2f1)=>{_0x51c2f1['forEach']((_0x50f3dd,_0x398cb3)=>{const _0xe4fbfa=_0x43b1;let _0x2bda76=0x1;result+=_0xe4fbfa(0x129)+mainNumber+']\x20'+_0x50f3dd['title']+'*\x0a',reply(_0xe4fbfa(0x127)+_0x2bda76++ +_0x398cb3+result),_0x398cb3['push'](Json(_0x1305d0));});},listMessage=async(_0x30cf0c,_0x407303)=>{const _0x1db857=_0x2521fb;_0x407303[_0x1db857(0x11f)]((_0x39930d,_0x2338a3)=>{const _0xd8e47e=_0x1db857;let _0x512d6f=0x1;result+='\x0a*['+mainNumber+']\x20'+_0x39930d['title']+'*\x0a',reply('*Select\x20number'+_0x512d6f++ +_0x2338a3+result),_0x2338a3[_0xd8e47e(0x126)](Json(_0x30cf0c));});},module[_0x2521fb(0x128)]={'listMessage':listMessage,'buttonMessage':buttonMessage,'btregex':btregex};
